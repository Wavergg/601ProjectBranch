
	<h1>Welcome to CodeIgniter!</h1>
	<h1><?php echo $passwd; ?></h1>
