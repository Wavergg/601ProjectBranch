<html>
<head>
<title>Upload Form</title>
</head>
<body>

<?php echo $error;?>


</body>
</html>