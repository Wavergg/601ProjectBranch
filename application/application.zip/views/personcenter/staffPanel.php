<!-- this is a pane for admin so far the only working things is manageStaff-->
<div class="this row justify-content-around">
   
        <div class="card border border-dark col-md-6 p-0 m-0">

            <a href="<?php echo base_url()?>index.php/personcenter/personalInfo" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
                <div class="row justify-content-center card-body">
                <img style="width:150px;height:150px;"  src="<?php echo base_url()?>lib/images/AddInfo.png">
                </div>
                <div class="card-title font-weight-bold">Updating your personal Information</div>
                <p class="card-text text-justify m-4 text-center">Updating your personal data, changing password and more.</p>
    
            </div> </a>
        </div> 
        
        <div class="card border border-dark col-md-6 p-0 m-0">

            <a href="<?php echo base_url()?>" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
                <div class="row justify-content-center card-body">
                <img style="width:150px;height:150px;"  src="<?php echo base_url()?>lib/images/NewApplicants.png">
                </div>
                <div class="card-title font-weight-bold">Look for new Applicants</div>
                <p class="card-text text-justify m-4 text-center">See what's new since your last login.</p>
    
            </div> </a>
        </div> 
    </div>
    <div class="this row">
   
    <div class="card border border-dark col-md-4 p-0 m-0">

<a href="<?php echo base_url()?>index.php/Archive" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
    <div class="row justify-content-center card-body">
    <img style="width:150px;height:150px;"  src="<?php echo base_url()?>lib/images/Archive.png">
    </div>
    <div class="card-title font-weight-bold">Archives</div>
    <p class="card-text text-justify m-4">Search the information of the pasts archives.</p>

</div> </a>
</div> 
<div class="card border border-dark col-md-4 p-0 m-0">

<a href="<?php echo base_url()?>index.php/Jobs/manageClient" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
    <div class="row justify-content-center card-body">
    <img style="width:150px;height:150px;"  src="<?php echo base_url()?>lib/images/Client.png">
    </div>
    <div class="card-title font-weight-bold">Manage Clients</div>
    <p class="card-text text-justify m-4">Look through the clients applications, publish and assign candidates.</p>

</div> </a>
</div>
    <div class="card border border-dark col-md-4 p-0 m-0">

    <a href="<?php echo base_url()?>index.php/candidateMission/manageCandidate/" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
        <div class="row justify-content-center card-body">
        <img style="width:150px;height:150px;"  src="<?php echo base_url()?>lib/images/Candidates.png">
        </div>
        <div class="card-title font-weight-bold">Manage Candidates</div>
        <p class="card-text text-justify m-4">Look through the candidates applications and their detailed informations.</p>

    </div> </a>
    </div> 
</div>