<!-- this is a pane for admin so far the only working things is manageStaff-->
<div class="this row justify-content-around">
   
        <div class="card border border-dark col-md-6 p-0 m-0">

            <a href="<?php echo base_url()?>index.php/personcenter/personalInfo" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
                <div class="row justify-content-center card-body">
                <img style="width:150px;height:150px;"  src="<?php echo base_url()?>lib/images/AddInfo.png">
                </div>
                <div class="card-title font-weight-bold">Updating your personal Information</div>
                <p class="card-text text-justify m-4 text-center">Updating your personal data, changing password and more.</p>
    
            </div> </a>
        </div> 
        
        <div class="card border border-dark col-md-6 p-0 m-0">

            <a href="<?php echo base_url()?>index.php/CandidateMission/index/active/" style="color: black; text-decoration:none"><div class="container p-0 m-0 mt-4 text-center">
                <div class="row justify-content-center card-body">
                <img style="width:125px;height:150px;"  src="<?php echo base_url()?>lib/images/SubmitCV.png">
                </div>
                <div class="card-title font-weight-bold">Apply for a job</div>
                <p class="card-text text-justify m-4 text-center">Submit your job application to Lee Recruitment.</p>
            </div> </a>
        </div> 
</div>